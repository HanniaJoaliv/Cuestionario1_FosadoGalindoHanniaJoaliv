# Cargar librerías necesarias
library(tidyverse)  # Para manipulación de datos
library(lubridate)  # Para manejar fechas

# 1. Crear un dataset de ejemplo
set.seed(123)  # Para reproducibilidad
dataset <- data.frame(
  categoria_variable = sample(c("A", "B", "C"), 100, replace = TRUE),
  variable_numerica = rnorm(100, mean = 50, sd = 10),
  likes = sample(1:100, 100, replace = TRUE),
  shares = sample(1:50, 100, replace = TRUE),
  fecha = sample(seq(as.Date('2020/01/01'), as.Date('2023/01/01'), by="day"), 100)
)

# 2. Convertir variables categóricas en factores
dataset$categoria_variable <- as.factor(dataset$categoria_variable)

# 3. Normalizar valores numéricos (Min-Max)
dataset$variable_numerica_normalizada <- (dataset$variable_numerica - min(dataset$variable_numerica, na.rm = TRUE)) / 
  (max(dataset$variable_numerica, na.rm = TRUE) - min(dataset$variable_numerica, na.rm = TRUE))

# 4. Crear nueva variable derivada
dataset$interaccion_total <- dataset$likes + dataset$shares

# 5. Convertir fechas a formato adecuado
# Si las fechas están en formato "dd/mm/yyyy"
# dataset$fecha <- dmy(dataset$fecha)  # Descomentar si es necesario

# O si están en formato "yyyy-mm-dd"
dataset$fecha <- ymd(dataset$fecha)

# Mostrar el dataset limpio
print(dataset)
